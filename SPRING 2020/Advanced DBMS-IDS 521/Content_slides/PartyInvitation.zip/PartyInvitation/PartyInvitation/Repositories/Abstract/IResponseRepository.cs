﻿using System;
using System.Collections.Generic;
using System.Linq;
using PartyInvitation.Models;

namespace PartyInvitation.Repositories.Abstract
{
   public interface IResponseRepository
    {
        IQueryable<GuestResponse> Responses { get; }
        void SaveResponse(GuestResponse response);
        void EditResponse(GuestResponse response);
        GuestResponse DeleteResponse(String guestName);
    }
}