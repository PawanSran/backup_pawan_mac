﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PartyInvitation.Repositories.Abstract;
using PartyInvitation.Models;
using MongoDB.Driver;
using MongoDB.Bson;

namespace PartyInvitation.Repositories.Concrete
{
    public class MongoDBResponseRepository: IResponseRepository
    {
        private MongoContext context = new MongoContext();

        public IQueryable<GuestResponse> Responses
        {
            get { return context.ResponseCollection; }
        }

        public void SaveResponse(GuestResponse response)
        {
            var coll = context.mgDb.GetCollection<GuestResponse>("responseCollection");
            coll.InsertOne(response);
        }

        public void EditResponse(GuestResponse response)
        {
            var coll = context.mgDb.GetCollection<BsonDocument>("responseCollection");
            var filter = Builders<BsonDocument>.Filter.Eq("Name", response.Name);
            var update = Builders<BsonDocument>.Update
                .Set("Email", response.Email)
                .Set("Phone", response.Phone)
                .Set("WillAttend", response.WillAttend);
            var result = coll.UpdateOne(filter, update);
        }

        public GuestResponse DeleteResponse(String guestName)
        {
            GuestResponse guestResponse = Responses.FirstOrDefault(r => r.Name.ToLower()==guestName.ToLower());
            var collection = context.mgDb.GetCollection<BsonDocument>("responseCollection");
            var filter = Builders<BsonDocument>.Filter.Eq("Name", guestName);
            var result = collection.DeleteOne(filter);
            return guestResponse;
        }

    }
}