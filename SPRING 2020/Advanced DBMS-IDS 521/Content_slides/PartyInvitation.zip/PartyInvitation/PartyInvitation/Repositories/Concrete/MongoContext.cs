﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MongoDB.Driver;
using PartyInvitation.Models;

namespace PartyInvitation.Repositories.Concrete
{
    public class MongoContext
    {
        public IMongoDatabase mgDb;
        public MongoContext()
        {
            var connectionstring = "mongodb://localhost:27017";
            var client = new MongoClient(connectionstring);
            mgDb = client.GetDatabase("PartyDB");
        }

        public IQueryable<GuestResponse> ResponseCollection
        {
            get
            {
                return mgDb.GetCollection<GuestResponse>("responseCollection").AsQueryable<GuestResponse>();
            }
        }
    }
}
