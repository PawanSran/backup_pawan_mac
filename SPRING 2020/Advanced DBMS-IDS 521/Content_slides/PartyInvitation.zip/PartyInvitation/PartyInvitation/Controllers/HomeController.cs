﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PartyInvitation.Models;
using MongoDB.Driver;
using PartyInvitation.Repositories.Concrete;

namespace PartyInvitation.Controllers
{
    public class HomeController : Controller
    {
        private MongoDBResponseRepository repository;

        //constructor
        public HomeController()
        {
            repository = new MongoDBResponseRepository();
        }

        // GET: Home
        public ViewResult Index()
        {
            int hour = DateTime.Now.Hour;
            ViewBag.Greeting = hour < 12 ? "Good Morning" : "Good Afternoon";
            return View();
        }

        [HttpGet]
        public ViewResult RsvpForm()
        {
            return View();
        }

        [HttpPost]
        public ViewResult RsvpForm(GuestResponse guestResponse)
        {
            if (ModelState.IsValid)
            {
                repository.SaveResponse(guestResponse);
                return View("Thanks", guestResponse);
            }
            else
            {
                // there is a validation error
                return View();
            }
        }

        public ViewResult GuestResponses()
        {
            return View(repository.Responses);
        }

        public ViewResult List()
        {            
            return View(repository.Responses);
        }

        public ViewResult Edit(String name)
        {
            GuestResponse response = repository.Responses
                                     .FirstOrDefault(r => r.Name == name);
            return View(response);
        }

        [HttpPost]
        public ActionResult Edit(GuestResponse response)
        {
            if (ModelState.IsValid)
            {
                repository.EditResponse(response);
                return RedirectToAction("List");
            }
            else
            {
                // there is something wrong with the data values
                return View(response);
            }
        }

        [HttpPost]
        public ActionResult Delete(String name)
        {
            GuestResponse deletedResponse = repository.DeleteResponse(name);
            return RedirectToAction("List");
        }

    }
}